from django.apps import AppConfig


class MapperConfig(AppConfig):
    name = 'mapper'
